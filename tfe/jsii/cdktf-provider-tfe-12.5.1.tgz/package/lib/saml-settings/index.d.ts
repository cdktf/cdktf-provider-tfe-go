/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SamlSettingsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Team Attribute Name specifies the name of the SAML attribute that determines team membership
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#attr_groups SamlSettings#attr_groups}
    */
    readonly attrGroups?: string;
    /**
    * Specifies the role for site admin access. Overrides the "Site Admin Role" method
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#attr_site_admin SamlSettings#attr_site_admin}
    */
    readonly attrSiteAdmin?: string;
    /**
    * Username Attribute Name specifies the name of the SAML attribute that determines the user's username
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#attr_username SamlSettings#attr_username}
    */
    readonly attrUsername?: string;
    /**
    * Ensure that <samlp:AuthnRequest> messages are signed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#authn_requests_signed SamlSettings#authn_requests_signed}
    */
    readonly authnRequestsSigned?: boolean | cdktf.IResolvable;
    /**
    * The certificate used for request and assertion signing
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#certificate SamlSettings#certificate}
    */
    readonly certificate?: string;
    /**
    * When sign-on fails and this is enabled, the SAMLResponse XML will be displayed on the login page
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#debug SamlSettings#debug}
    */
    readonly debug?: boolean | cdktf.IResolvable;
    /**
    * Identity Provider Certificate specifies the PEM encoded X.509 Certificate as provided by the IdP configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#idp_cert SamlSettings#idp_cert}
    */
    readonly idpCert: string;
    /**
    * The private key used for request and assertion signing
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#private_key SamlSettings#private_key}
    */
    readonly privateKey?: string;
    /**
    * The private key in write-only mode used for request and assertion signing
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#private_key_wo SamlSettings#private_key_wo}
    */
    readonly privateKeyWo?: string;
    /**
    * Signature Digest Method. Must be either `SHA1` or `SHA256`. Defaults to `SHA256`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#signature_digest_method SamlSettings#signature_digest_method}
    */
    readonly signatureDigestMethod?: string;
    /**
    * Signature Signing Method. Must be either `SHA1` or `SHA256`. Defaults to `SHA256`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#signature_signing_method SamlSettings#signature_signing_method}
    */
    readonly signatureSigningMethod?: string;
    /**
    * Specifies the role for site admin access, provided in the list of roles sent in the Team Attribute Name attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#site_admin_role SamlSettings#site_admin_role}
    */
    readonly siteAdminRole?: string;
    /**
    * Single Log Out URL specifies the HTTPS endpoint on your IdP for single logout requests. This value is provided by the IdP configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#slo_endpoint_url SamlSettings#slo_endpoint_url}
    */
    readonly sloEndpointUrl: string;
    /**
    * Specifies the Single Sign On session timeout in seconds. Defaults to 14 days
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#sso_api_token_session_timeout SamlSettings#sso_api_token_session_timeout}
    */
    readonly ssoApiTokenSessionTimeout?: number;
    /**
    * Single Sign On URL specifies the HTTPS endpoint on your IdP for single sign-on requests. This value is provided by the IdP configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#sso_endpoint_url SamlSettings#sso_endpoint_url}
    */
    readonly ssoEndpointUrl: string;
    /**
    * Set it to false if you would rather use Terraform Enterprise to manage team membership
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#team_management_enabled SamlSettings#team_management_enabled}
    */
    readonly teamManagementEnabled?: boolean | cdktf.IResolvable;
    /**
    * Ensure that <saml:Assertion> elements are signed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#want_assertions_signed SamlSettings#want_assertions_signed}
    */
    readonly wantAssertionsSigned?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings tfe_saml_settings}
*/
export declare class SamlSettings extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_saml_settings";
    /**
    * Generates CDKTF code for importing a SamlSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SamlSettings to import
    * @param importFromId The id of the existing SamlSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SamlSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/saml_settings tfe_saml_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SamlSettingsConfig
    */
    constructor(scope: Construct, id: string, config: SamlSettingsConfig);
    get acsConsumerUrl(): string;
    private _attrGroups?;
    get attrGroups(): string;
    set attrGroups(value: string);
    resetAttrGroups(): void;
    get attrGroupsInput(): string | undefined;
    private _attrSiteAdmin?;
    get attrSiteAdmin(): string;
    set attrSiteAdmin(value: string);
    resetAttrSiteAdmin(): void;
    get attrSiteAdminInput(): string | undefined;
    private _attrUsername?;
    get attrUsername(): string;
    set attrUsername(value: string);
    resetAttrUsername(): void;
    get attrUsernameInput(): string | undefined;
    private _authnRequestsSigned?;
    get authnRequestsSigned(): boolean | cdktf.IResolvable;
    set authnRequestsSigned(value: boolean | cdktf.IResolvable);
    resetAuthnRequestsSigned(): void;
    get authnRequestsSignedInput(): boolean | cdktf.IResolvable | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _debug?;
    get debug(): boolean | cdktf.IResolvable;
    set debug(value: boolean | cdktf.IResolvable);
    resetDebug(): void;
    get debugInput(): boolean | cdktf.IResolvable | undefined;
    get enabled(): cdktf.IResolvable;
    get id(): string;
    private _idpCert?;
    get idpCert(): string;
    set idpCert(value: string);
    get idpCertInput(): string | undefined;
    get metadataUrl(): string;
    get oldIdpCert(): string;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _privateKeyWo?;
    get privateKeyWo(): string;
    set privateKeyWo(value: string);
    resetPrivateKeyWo(): void;
    get privateKeyWoInput(): string | undefined;
    private _signatureDigestMethod?;
    get signatureDigestMethod(): string;
    set signatureDigestMethod(value: string);
    resetSignatureDigestMethod(): void;
    get signatureDigestMethodInput(): string | undefined;
    private _signatureSigningMethod?;
    get signatureSigningMethod(): string;
    set signatureSigningMethod(value: string);
    resetSignatureSigningMethod(): void;
    get signatureSigningMethodInput(): string | undefined;
    private _siteAdminRole?;
    get siteAdminRole(): string;
    set siteAdminRole(value: string);
    resetSiteAdminRole(): void;
    get siteAdminRoleInput(): string | undefined;
    private _sloEndpointUrl?;
    get sloEndpointUrl(): string;
    set sloEndpointUrl(value: string);
    get sloEndpointUrlInput(): string | undefined;
    private _ssoApiTokenSessionTimeout?;
    get ssoApiTokenSessionTimeout(): number;
    set ssoApiTokenSessionTimeout(value: number);
    resetSsoApiTokenSessionTimeout(): void;
    get ssoApiTokenSessionTimeoutInput(): number | undefined;
    private _ssoEndpointUrl?;
    get ssoEndpointUrl(): string;
    set ssoEndpointUrl(value: string);
    get ssoEndpointUrlInput(): string | undefined;
    private _teamManagementEnabled?;
    get teamManagementEnabled(): boolean | cdktf.IResolvable;
    set teamManagementEnabled(value: boolean | cdktf.IResolvable);
    resetTeamManagementEnabled(): void;
    get teamManagementEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _wantAssertionsSigned?;
    get wantAssertionsSigned(): boolean | cdktf.IResolvable;
    set wantAssertionsSigned(value: boolean | cdktf.IResolvable);
    resetWantAssertionsSigned(): void;
    get wantAssertionsSignedInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
