/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TeamProjectAccessConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#access TeamProjectAccess#access}
    */
    readonly access: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#id TeamProjectAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#project_id TeamProjectAccess#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#team_id TeamProjectAccess#team_id}
    */
    readonly teamId: string;
    /**
    * project_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#project_access TeamProjectAccess#project_access}
    */
    readonly projectAccess?: TeamProjectAccessProjectAccess[] | cdktf.IResolvable;
    /**
    * workspace_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#workspace_access TeamProjectAccess#workspace_access}
    */
    readonly workspaceAccess?: TeamProjectAccessWorkspaceAccess[] | cdktf.IResolvable;
}
export interface TeamProjectAccessProjectAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#settings TeamProjectAccess#settings}
    */
    readonly settings?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#teams TeamProjectAccess#teams}
    */
    readonly teams?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#variable_sets TeamProjectAccess#variable_sets}
    */
    readonly variableSets?: string;
}
export declare function teamProjectAccessProjectAccessToTerraform(struct?: TeamProjectAccessProjectAccess | cdktf.IResolvable): any;
export declare function teamProjectAccessProjectAccessToHclTerraform(struct?: TeamProjectAccessProjectAccess | cdktf.IResolvable): any;
export declare class TeamProjectAccessProjectAccessOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TeamProjectAccessProjectAccess | cdktf.IResolvable | undefined;
    set internalValue(value: TeamProjectAccessProjectAccess | cdktf.IResolvable | undefined);
    private _settings?;
    get settings(): string;
    set settings(value: string);
    resetSettings(): void;
    get settingsInput(): string | undefined;
    private _teams?;
    get teams(): string;
    set teams(value: string);
    resetTeams(): void;
    get teamsInput(): string | undefined;
    private _variableSets?;
    get variableSets(): string;
    set variableSets(value: string);
    resetVariableSets(): void;
    get variableSetsInput(): string | undefined;
}
export declare class TeamProjectAccessProjectAccessList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TeamProjectAccessProjectAccess[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TeamProjectAccessProjectAccessOutputReference;
}
export interface TeamProjectAccessWorkspaceAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#create TeamProjectAccess#create}
    */
    readonly create?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#delete TeamProjectAccess#delete}
    */
    readonly delete?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#locking TeamProjectAccess#locking}
    */
    readonly locking?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#move TeamProjectAccess#move}
    */
    readonly move?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#run_tasks TeamProjectAccess#run_tasks}
    */
    readonly runTasks?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#runs TeamProjectAccess#runs}
    */
    readonly runs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#sentinel_mocks TeamProjectAccess#sentinel_mocks}
    */
    readonly sentinelMocks?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#state_versions TeamProjectAccess#state_versions}
    */
    readonly stateVersions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#variables TeamProjectAccess#variables}
    */
    readonly variables?: string;
}
export declare function teamProjectAccessWorkspaceAccessToTerraform(struct?: TeamProjectAccessWorkspaceAccess | cdktf.IResolvable): any;
export declare function teamProjectAccessWorkspaceAccessToHclTerraform(struct?: TeamProjectAccessWorkspaceAccess | cdktf.IResolvable): any;
export declare class TeamProjectAccessWorkspaceAccessOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TeamProjectAccessWorkspaceAccess | cdktf.IResolvable | undefined;
    set internalValue(value: TeamProjectAccessWorkspaceAccess | cdktf.IResolvable | undefined);
    private _create?;
    get create(): boolean | cdktf.IResolvable;
    set create(value: boolean | cdktf.IResolvable);
    resetCreate(): void;
    get createInput(): boolean | cdktf.IResolvable | undefined;
    private _delete?;
    get delete(): boolean | cdktf.IResolvable;
    set delete(value: boolean | cdktf.IResolvable);
    resetDelete(): void;
    get deleteInput(): boolean | cdktf.IResolvable | undefined;
    private _locking?;
    get locking(): boolean | cdktf.IResolvable;
    set locking(value: boolean | cdktf.IResolvable);
    resetLocking(): void;
    get lockingInput(): boolean | cdktf.IResolvable | undefined;
    private _move?;
    get move(): boolean | cdktf.IResolvable;
    set move(value: boolean | cdktf.IResolvable);
    resetMove(): void;
    get moveInput(): boolean | cdktf.IResolvable | undefined;
    private _runTasks?;
    get runTasks(): boolean | cdktf.IResolvable;
    set runTasks(value: boolean | cdktf.IResolvable);
    resetRunTasks(): void;
    get runTasksInput(): boolean | cdktf.IResolvable | undefined;
    private _runs?;
    get runs(): string;
    set runs(value: string);
    resetRuns(): void;
    get runsInput(): string | undefined;
    private _sentinelMocks?;
    get sentinelMocks(): string;
    set sentinelMocks(value: string);
    resetSentinelMocks(): void;
    get sentinelMocksInput(): string | undefined;
    private _stateVersions?;
    get stateVersions(): string;
    set stateVersions(value: string);
    resetStateVersions(): void;
    get stateVersionsInput(): string | undefined;
    private _variables?;
    get variables(): string;
    set variables(value: string);
    resetVariables(): void;
    get variablesInput(): string | undefined;
}
export declare class TeamProjectAccessWorkspaceAccessList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TeamProjectAccessWorkspaceAccess[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TeamProjectAccessWorkspaceAccessOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access tfe_team_project_access}
*/
export declare class TeamProjectAccess extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_team_project_access";
    /**
    * Generates CDKTF code for importing a TeamProjectAccess resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamProjectAccess to import
    * @param importFromId The id of the existing TeamProjectAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamProjectAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/team_project_access tfe_team_project_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamProjectAccessConfig
    */
    constructor(scope: Construct, id: string, config: TeamProjectAccessConfig);
    private _access?;
    get access(): string;
    set access(value: string);
    get accessInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _projectAccess;
    get projectAccess(): TeamProjectAccessProjectAccessList;
    putProjectAccess(value: TeamProjectAccessProjectAccess[] | cdktf.IResolvable): void;
    resetProjectAccess(): void;
    get projectAccessInput(): cdktf.IResolvable | TeamProjectAccessProjectAccess[] | undefined;
    private _workspaceAccess;
    get workspaceAccess(): TeamProjectAccessWorkspaceAccessList;
    putWorkspaceAccess(value: TeamProjectAccessWorkspaceAccess[] | cdktf.IResolvable): void;
    resetWorkspaceAccess(): void;
    get workspaceAccessInput(): cdktf.IResolvable | TeamProjectAccessWorkspaceAccess[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
