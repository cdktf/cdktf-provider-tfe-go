/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WorkspaceSettingsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#agent_pool_id WorkspaceSettings#agent_pool_id}
    */
    readonly agentPoolId?: string;
    /**
    * If set to true, assessments will be enabled for the workspace. This includes drift and continuous validation checks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#assessments_enabled WorkspaceSettings#assessments_enabled}
    */
    readonly assessmentsEnabled?: boolean | cdktf.IResolvable;
    /**
    * If set to false a human will have to manually confirm a plan in HCP Terraform's UI to start an apply. If set to true, this resource will be automatically applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#auto_apply WorkspaceSettings#auto_apply}
    */
    readonly autoApply?: boolean | cdktf.IResolvable;
    /**
    * A description of the workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#description WorkspaceSettings#description}
    */
    readonly description?: string;
    /**
    * A map of all key-value tags set on the workspace (includes inheritted tags).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#effective_tags WorkspaceSettings#effective_tags}
    */
    readonly effectiveTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#execution_mode WorkspaceSettings#execution_mode}
    */
    readonly executionMode?: string;
    /**
    * Whether the workspace allows all workspaces in the organization to access its state data during runs. If false, then only workspaces defined in `remote_state_consumer_ids` can access its state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#global_remote_state WorkspaceSettings#global_remote_state}
    */
    readonly globalRemoteState?: boolean | cdktf.IResolvable;
    /**
    * The set of workspace IDs set as explicit remote state consumers for the given workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#remote_state_consumer_ids WorkspaceSettings#remote_state_consumer_ids}
    */
    readonly remoteStateConsumerIds?: string[];
    /**
    * A map of key-value tags to add to the workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#tags WorkspaceSettings#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#workspace_id WorkspaceSettings#workspace_id}
    */
    readonly workspaceId: string;
}
export interface WorkspaceSettingsOverwrites {
}
export declare function workspaceSettingsOverwritesToTerraform(struct?: WorkspaceSettingsOverwrites): any;
export declare function workspaceSettingsOverwritesToHclTerraform(struct?: WorkspaceSettingsOverwrites): any;
export declare class WorkspaceSettingsOverwritesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkspaceSettingsOverwrites | undefined;
    set internalValue(value: WorkspaceSettingsOverwrites | undefined);
    get agentPool(): cdktf.IResolvable;
    get executionMode(): cdktf.IResolvable;
}
export declare class WorkspaceSettingsOverwritesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkspaceSettingsOverwritesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings tfe_workspace_settings}
*/
export declare class WorkspaceSettings extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_workspace_settings";
    /**
    * Generates CDKTF code for importing a WorkspaceSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceSettings to import
    * @param importFromId The id of the existing WorkspaceSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_settings tfe_workspace_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceSettingsConfig
    */
    constructor(scope: Construct, id: string, config: WorkspaceSettingsConfig);
    private _agentPoolId?;
    get agentPoolId(): string;
    set agentPoolId(value: string);
    resetAgentPoolId(): void;
    get agentPoolIdInput(): string | undefined;
    private _assessmentsEnabled?;
    get assessmentsEnabled(): boolean | cdktf.IResolvable;
    set assessmentsEnabled(value: boolean | cdktf.IResolvable);
    resetAssessmentsEnabled(): void;
    get assessmentsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _autoApply?;
    get autoApply(): boolean | cdktf.IResolvable;
    set autoApply(value: boolean | cdktf.IResolvable);
    resetAutoApply(): void;
    get autoApplyInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveTags?;
    get effectiveTags(): {
        [key: string]: string;
    };
    set effectiveTags(value: {
        [key: string]: string;
    });
    resetEffectiveTags(): void;
    get effectiveTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _executionMode?;
    get executionMode(): string;
    set executionMode(value: string);
    resetExecutionMode(): void;
    get executionModeInput(): string | undefined;
    private _globalRemoteState?;
    get globalRemoteState(): boolean | cdktf.IResolvable;
    set globalRemoteState(value: boolean | cdktf.IResolvable);
    resetGlobalRemoteState(): void;
    get globalRemoteStateInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _overwrites;
    get overwrites(): WorkspaceSettingsOverwritesList;
    private _remoteStateConsumerIds?;
    get remoteStateConsumerIds(): string[];
    set remoteStateConsumerIds(value: string[]);
    resetRemoteStateConsumerIds(): void;
    get remoteStateConsumerIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
