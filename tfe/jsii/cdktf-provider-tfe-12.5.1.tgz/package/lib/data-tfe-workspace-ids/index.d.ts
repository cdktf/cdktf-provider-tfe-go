/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeWorkspaceIdsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#exclude_tags DataTfeWorkspaceIds#exclude_tags}
    */
    readonly excludeTags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#id DataTfeWorkspaceIds#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#names DataTfeWorkspaceIds#names}
    */
    readonly names?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#organization DataTfeWorkspaceIds#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#tag_names DataTfeWorkspaceIds#tag_names}
    */
    readonly tagNames?: string[];
    /**
    * tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#tag_filters DataTfeWorkspaceIds#tag_filters}
    */
    readonly tagFilters?: DataTfeWorkspaceIdsTagFilters;
}
export interface DataTfeWorkspaceIdsTagFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#exclude DataTfeWorkspaceIds#exclude}
    */
    readonly exclude?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#include DataTfeWorkspaceIds#include}
    */
    readonly include?: {
        [key: string]: string;
    };
}
export declare function dataTfeWorkspaceIdsTagFiltersToTerraform(struct?: DataTfeWorkspaceIdsTagFiltersOutputReference | DataTfeWorkspaceIdsTagFilters): any;
export declare function dataTfeWorkspaceIdsTagFiltersToHclTerraform(struct?: DataTfeWorkspaceIdsTagFiltersOutputReference | DataTfeWorkspaceIdsTagFilters): any;
export declare class DataTfeWorkspaceIdsTagFiltersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataTfeWorkspaceIdsTagFilters | undefined;
    set internalValue(value: DataTfeWorkspaceIdsTagFilters | undefined);
    private _exclude?;
    get exclude(): {
        [key: string]: string;
    };
    set exclude(value: {
        [key: string]: string;
    });
    resetExclude(): void;
    get excludeInput(): {
        [key: string]: string;
    } | undefined;
    private _include?;
    get include(): {
        [key: string]: string;
    };
    set include(value: {
        [key: string]: string;
    });
    resetInclude(): void;
    get includeInput(): {
        [key: string]: string;
    } | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids tfe_workspace_ids}
*/
export declare class DataTfeWorkspaceIds extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_workspace_ids";
    /**
    * Generates CDKTF code for importing a DataTfeWorkspaceIds resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeWorkspaceIds to import
    * @param importFromId The id of the existing DataTfeWorkspaceIds that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeWorkspaceIds to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/workspace_ids tfe_workspace_ids} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeWorkspaceIdsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeWorkspaceIdsConfig);
    private _excludeTags?;
    get excludeTags(): string[];
    set excludeTags(value: string[]);
    resetExcludeTags(): void;
    get excludeTagsInput(): string[] | undefined;
    private _fullNames;
    get fullNames(): cdktf.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids;
    get ids(): cdktf.StringMap;
    private _names?;
    get names(): string[];
    set names(value: string[]);
    resetNames(): void;
    get namesInput(): string[] | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _tagNames?;
    get tagNames(): string[];
    set tagNames(value: string[]);
    resetTagNames(): void;
    get tagNamesInput(): string[] | undefined;
    private _tagFilters;
    get tagFilters(): DataTfeWorkspaceIdsTagFiltersOutputReference;
    putTagFilters(value: DataTfeWorkspaceIdsTagFilters): void;
    resetTagFilters(): void;
    get tagFiltersInput(): DataTfeWorkspaceIdsTagFilters | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
