/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeTeamProjectAccessConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/team_project_access#id DataTfeTeamProjectAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/team_project_access#project_id DataTfeTeamProjectAccess#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/team_project_access#team_id DataTfeTeamProjectAccess#team_id}
    */
    readonly teamId: string;
}
export interface DataTfeTeamProjectAccessProjectAccess {
}
export declare function dataTfeTeamProjectAccessProjectAccessToTerraform(struct?: DataTfeTeamProjectAccessProjectAccess): any;
export declare function dataTfeTeamProjectAccessProjectAccessToHclTerraform(struct?: DataTfeTeamProjectAccessProjectAccess): any;
export declare class DataTfeTeamProjectAccessProjectAccessOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeTeamProjectAccessProjectAccess | undefined;
    set internalValue(value: DataTfeTeamProjectAccessProjectAccess | undefined);
    get settings(): string;
    get teams(): string;
    get variableSets(): string;
}
export declare class DataTfeTeamProjectAccessProjectAccessList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeTeamProjectAccessProjectAccessOutputReference;
}
export interface DataTfeTeamProjectAccessWorkspaceAccess {
}
export declare function dataTfeTeamProjectAccessWorkspaceAccessToTerraform(struct?: DataTfeTeamProjectAccessWorkspaceAccess): any;
export declare function dataTfeTeamProjectAccessWorkspaceAccessToHclTerraform(struct?: DataTfeTeamProjectAccessWorkspaceAccess): any;
export declare class DataTfeTeamProjectAccessWorkspaceAccessOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeTeamProjectAccessWorkspaceAccess | undefined;
    set internalValue(value: DataTfeTeamProjectAccessWorkspaceAccess | undefined);
    get create(): cdktf.IResolvable;
    get delete(): cdktf.IResolvable;
    get locking(): cdktf.IResolvable;
    get move(): cdktf.IResolvable;
    get runTasks(): cdktf.IResolvable;
    get runs(): string;
    get sentinelMocks(): string;
    get stateVersions(): string;
    get variables(): string;
}
export declare class DataTfeTeamProjectAccessWorkspaceAccessList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeTeamProjectAccessWorkspaceAccessOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/team_project_access tfe_team_project_access}
*/
export declare class DataTfeTeamProjectAccess extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_team_project_access";
    /**
    * Generates CDKTF code for importing a DataTfeTeamProjectAccess resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeTeamProjectAccess to import
    * @param importFromId The id of the existing DataTfeTeamProjectAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/team_project_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeTeamProjectAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/team_project_access tfe_team_project_access} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeTeamProjectAccessConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeTeamProjectAccessConfig);
    get access(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectAccess;
    get projectAccess(): DataTfeTeamProjectAccessProjectAccessList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _workspaceAccess;
    get workspaceAccess(): DataTfeTeamProjectAccessWorkspaceAccessList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
