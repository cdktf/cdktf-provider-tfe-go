/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectSettingsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/project_settings#default_agent_pool_id ProjectSettings#default_agent_pool_id}
    */
    readonly defaultAgentPoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/project_settings#default_execution_mode ProjectSettings#default_execution_mode}
    */
    readonly defaultExecutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/project_settings#project_id ProjectSettings#project_id}
    */
    readonly projectId: string;
}
export interface ProjectSettingsOverwrites {
}
export declare function projectSettingsOverwritesToTerraform(struct?: ProjectSettingsOverwrites): any;
export declare function projectSettingsOverwritesToHclTerraform(struct?: ProjectSettingsOverwrites): any;
export declare class ProjectSettingsOverwritesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectSettingsOverwrites | undefined;
    set internalValue(value: ProjectSettingsOverwrites | undefined);
    get defaultAgentPoolId(): cdktf.IResolvable;
    get defaultExecutionMode(): cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/project_settings tfe_project_settings}
*/
export declare class ProjectSettings extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_project_settings";
    /**
    * Generates CDKTF code for importing a ProjectSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectSettings to import
    * @param importFromId The id of the existing ProjectSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/project_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/project_settings tfe_project_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectSettingsConfig
    */
    constructor(scope: Construct, id: string, config: ProjectSettingsConfig);
    private _defaultAgentPoolId?;
    get defaultAgentPoolId(): string;
    set defaultAgentPoolId(value: string);
    resetDefaultAgentPoolId(): void;
    get defaultAgentPoolIdInput(): string | undefined;
    private _defaultExecutionMode?;
    get defaultExecutionMode(): string;
    set defaultExecutionMode(value: string);
    resetDefaultExecutionMode(): void;
    get defaultExecutionModeInput(): string | undefined;
    get id(): string;
    private _overwrites;
    get overwrites(): ProjectSettingsOverwritesOutputReference;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
