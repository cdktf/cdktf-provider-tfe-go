/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NotificationConfigurationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The type of notification configuration payload to send.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#destination_type NotificationConfiguration#destination_type}
    */
    readonly destinationType: string;
    /**
    * A list of email addresses. This value must not be provided if `destination_type` is `generic`, `microsoft-teams`, or `slack`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#email_addresses NotificationConfiguration#email_addresses}
    */
    readonly emailAddresses?: string[];
    /**
    * A list of user IDs. This value must not be provided if `destination_type` is `generic`, `microsoft-teams`, or `slack`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#email_user_ids NotificationConfiguration#email_user_ids}
    */
    readonly emailUserIds?: string[];
    /**
    * Whether the notification configuration should be enabled or not. Disabled configurations will not send any notifications. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#enabled NotificationConfiguration#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Name of the notification configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#name NotificationConfiguration#name}
    */
    readonly name: string;
    /**
    * A write-only secure token for the notification configuration, which can be used by the receiving server to verify request authenticity when configured for notification configurations with a destination type of `generic`. Defaults to `null`. This value _must not_ be provided if `destination_type` is `email`, `microsoft-teams`, or `slack`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#token NotificationConfiguration#token}
    */
    readonly token?: string;
    /**
    * Value of the token in write-only mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#token_wo NotificationConfiguration#token_wo}
    */
    readonly tokenWo?: string;
    /**
    * The array of triggers for which this notification configuration will send notifications. If omitted, no notification triggers are configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#triggers NotificationConfiguration#triggers}
    */
    readonly triggers?: string[];
    /**
    * The HTTP or HTTPS URL where notification requests will be made. This value must not be provided if `email_addresses` or `email_user_ids` is present, or if `destination_type` is `email`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#url NotificationConfiguration#url}
    */
    readonly url?: string;
    /**
    * The ID of the workspace that owns the notification configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#workspace_id NotificationConfiguration#workspace_id}
    */
    readonly workspaceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration tfe_notification_configuration}
*/
export declare class NotificationConfiguration extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_notification_configuration";
    /**
    * Generates CDKTF code for importing a NotificationConfiguration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationConfiguration to import
    * @param importFromId The id of the existing NotificationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/notification_configuration tfe_notification_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: NotificationConfigurationConfig);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
    private _emailUserIds?;
    get emailUserIds(): string[];
    set emailUserIds(value: string[]);
    resetEmailUserIds(): void;
    get emailUserIdsInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _tokenWo?;
    get tokenWo(): string;
    set tokenWo(value: string);
    resetTokenWo(): void;
    get tokenWoInput(): string | undefined;
    private _triggers?;
    get triggers(): string[];
    set triggers(value: string[]);
    resetTriggers(): void;
    get triggersInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
