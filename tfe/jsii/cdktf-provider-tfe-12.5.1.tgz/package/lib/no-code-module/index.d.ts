/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NoCodeModuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#enabled NoCodeModule#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#id NoCodeModule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#organization NoCodeModule#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#registry_module NoCodeModule#registry_module}
    */
    readonly registryModule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#version_pin NoCodeModule#version_pin}
    */
    readonly versionPin?: string;
    /**
    * variable_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#variable_options NoCodeModule#variable_options}
    */
    readonly variableOptions?: NoCodeModuleVariableOptions[] | cdktf.IResolvable;
}
export interface NoCodeModuleVariableOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#name NoCodeModule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#options NoCodeModule#options}
    */
    readonly options: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#type NoCodeModule#type}
    */
    readonly type: string;
}
export declare function noCodeModuleVariableOptionsToTerraform(struct?: NoCodeModuleVariableOptions | cdktf.IResolvable): any;
export declare function noCodeModuleVariableOptionsToHclTerraform(struct?: NoCodeModuleVariableOptions | cdktf.IResolvable): any;
export declare class NoCodeModuleVariableOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NoCodeModuleVariableOptions | cdktf.IResolvable | undefined;
    set internalValue(value: NoCodeModuleVariableOptions | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options?;
    get options(): string[];
    set options(value: string[]);
    get optionsInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class NoCodeModuleVariableOptionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NoCodeModuleVariableOptions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NoCodeModuleVariableOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module tfe_no_code_module}
*/
export declare class NoCodeModule extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_no_code_module";
    /**
    * Generates CDKTF code for importing a NoCodeModule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NoCodeModule to import
    * @param importFromId The id of the existing NoCodeModule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NoCodeModule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/no_code_module tfe_no_code_module} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NoCodeModuleConfig
    */
    constructor(scope: Construct, id: string, config: NoCodeModuleConfig);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _registryModule?;
    get registryModule(): string;
    set registryModule(value: string);
    get registryModuleInput(): string | undefined;
    private _versionPin?;
    get versionPin(): string;
    set versionPin(value: string);
    resetVersionPin(): void;
    get versionPinInput(): string | undefined;
    private _variableOptions;
    get variableOptions(): NoCodeModuleVariableOptionsList;
    putVariableOptions(value: NoCodeModuleVariableOptions[] | cdktf.IResolvable): void;
    resetVariableOptions(): void;
    get variableOptionsInput(): cdktf.IResolvable | NoCodeModuleVariableOptions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
