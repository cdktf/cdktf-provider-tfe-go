/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface StackConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of an agent pool to assign to the stack
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#agent_pool_id Stack#agent_pool_id}
    */
    readonly agentPoolId?: string;
    /**
    * Description of the Stack
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#description Stack#description}
    */
    readonly description?: string;
    /**
    * Name of the Stack
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#name Stack#name}
    */
    readonly name: string;
    /**
    * ID of the project that the Stack belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#project_id Stack#project_id}
    */
    readonly projectId: string;
    /**
    * vcs_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#vcs_repo Stack#vcs_repo}
    */
    readonly vcsRepo?: StackVcsRepo;
}
export interface StackVcsRepo {
    /**
    * The repository branch that Terraform should use. This defaults to the respository's default branch (e.g. main).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#branch Stack#branch}
    */
    readonly branch?: string;
    /**
    * The installation ID of the GitHub App. This conflicts with `oauth_token_id` and can only be used if `oauth_token_id` is not used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#github_app_installation_id Stack#github_app_installation_id}
    */
    readonly githubAppInstallationId?: string;
    /**
    * Identifier of the VCS repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#identifier Stack#identifier}
    */
    readonly identifier?: string;
    /**
    * The VCS Connection to use. This ID can be obtained from a `tfe_oauth_client` resource. This conflicts with `github_app_installation_id` and can only be used if `github_app_installation_id` is not used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#oauth_token_id Stack#oauth_token_id}
    */
    readonly oauthTokenId?: string;
}
export declare function stackVcsRepoToTerraform(struct?: StackVcsRepo | cdktf.IResolvable): any;
export declare function stackVcsRepoToHclTerraform(struct?: StackVcsRepo | cdktf.IResolvable): any;
export declare class StackVcsRepoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StackVcsRepo | cdktf.IResolvable | undefined;
    set internalValue(value: StackVcsRepo | cdktf.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _githubAppInstallationId?;
    get githubAppInstallationId(): string;
    set githubAppInstallationId(value: string);
    resetGithubAppInstallationId(): void;
    get githubAppInstallationIdInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    resetIdentifier(): void;
    get identifierInput(): string | undefined;
    private _oauthTokenId?;
    get oauthTokenId(): string;
    set oauthTokenId(value: string);
    resetOauthTokenId(): void;
    get oauthTokenIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack tfe_stack}
*/
export declare class Stack extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_stack";
    /**
    * Generates CDKTF code for importing a Stack resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Stack to import
    * @param importFromId The id of the existing Stack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Stack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/stack tfe_stack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StackConfig
    */
    constructor(scope: Construct, id: string, config: StackConfig);
    private _agentPoolId?;
    get agentPoolId(): string;
    set agentPoolId(value: string);
    resetAgentPoolId(): void;
    get agentPoolIdInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get updatedAt(): string;
    private _vcsRepo;
    get vcsRepo(): StackVcsRepoOutputReference;
    putVcsRepo(value: StackVcsRepo): void;
    resetVcsRepo(): void;
    get vcsRepoInput(): cdktf.IResolvable | StackVcsRepo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
