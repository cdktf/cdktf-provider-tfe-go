/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataRetentionPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the organization. If omitted, organization must be defined in the provider config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy#organization DataRetentionPolicy#organization}
    */
    readonly organization?: string;
    /**
    * ID of the workspace that the data retention policy should apply to. If omitted, the data retention policy will apply to the entire organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy#workspace_id DataRetentionPolicy#workspace_id}
    */
    readonly workspaceId?: string;
    /**
    * delete_older_than block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy#delete_older_than DataRetentionPolicy#delete_older_than}
    */
    readonly deleteOlderThan?: DataRetentionPolicyDeleteOlderThan;
    /**
    * dont_delete block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy#dont_delete DataRetentionPolicy#dont_delete}
    */
    readonly dontDelete?: DataRetentionPolicyDontDelete;
}
export interface DataRetentionPolicyDeleteOlderThan {
    /**
    * Number of days
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy#days DataRetentionPolicy#days}
    */
    readonly days?: number;
}
export declare function dataRetentionPolicyDeleteOlderThanToTerraform(struct?: DataRetentionPolicyDeleteOlderThan | cdktf.IResolvable): any;
export declare function dataRetentionPolicyDeleteOlderThanToHclTerraform(struct?: DataRetentionPolicyDeleteOlderThan | cdktf.IResolvable): any;
export declare class DataRetentionPolicyDeleteOlderThanOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataRetentionPolicyDeleteOlderThan | cdktf.IResolvable | undefined;
    set internalValue(value: DataRetentionPolicyDeleteOlderThan | cdktf.IResolvable | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    resetDays(): void;
    get daysInput(): number | undefined;
}
export interface DataRetentionPolicyDontDelete {
}
export declare function dataRetentionPolicyDontDeleteToTerraform(struct?: DataRetentionPolicyDontDelete | cdktf.IResolvable): any;
export declare function dataRetentionPolicyDontDeleteToHclTerraform(struct?: DataRetentionPolicyDontDelete | cdktf.IResolvable): any;
export declare class DataRetentionPolicyDontDeleteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataRetentionPolicyDontDelete | cdktf.IResolvable | undefined;
    set internalValue(value: DataRetentionPolicyDontDelete | cdktf.IResolvable | undefined);
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy tfe_data_retention_policy}
*/
export declare class DataRetentionPolicy extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_data_retention_policy";
    /**
    * Generates CDKTF code for importing a DataRetentionPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataRetentionPolicy to import
    * @param importFromId The id of the existing DataRetentionPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataRetentionPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/data_retention_policy tfe_data_retention_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataRetentionPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataRetentionPolicyConfig);
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
    private _deleteOlderThan;
    get deleteOlderThan(): DataRetentionPolicyDeleteOlderThanOutputReference;
    putDeleteOlderThan(value: DataRetentionPolicyDeleteOlderThan): void;
    resetDeleteOlderThan(): void;
    get deleteOlderThanInput(): cdktf.IResolvable | DataRetentionPolicyDeleteOlderThan | undefined;
    private _dontDelete;
    get dontDelete(): DataRetentionPolicyDontDeleteOutputReference;
    putDontDelete(value: DataRetentionPolicyDontDelete): void;
    get dontDeleteInput(): cdktf.IResolvable | DataRetentionPolicyDontDelete | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
