/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeRegistryGpgKeysConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the organization. If omitted, organization must be defined in the provider config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_gpg_keys#organization DataTfeRegistryGpgKeys#organization}
    */
    readonly organization?: string;
}
export interface DataTfeRegistryGpgKeysKeys {
}
export declare function dataTfeRegistryGpgKeysKeysToTerraform(struct?: DataTfeRegistryGpgKeysKeys): any;
export declare function dataTfeRegistryGpgKeysKeysToHclTerraform(struct?: DataTfeRegistryGpgKeysKeys): any;
export declare class DataTfeRegistryGpgKeysKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeRegistryGpgKeysKeys | undefined;
    set internalValue(value: DataTfeRegistryGpgKeysKeys | undefined);
    get asciiArmor(): string;
    get createdAt(): string;
    get id(): string;
    get organization(): string;
    get updatedAt(): string;
}
export declare class DataTfeRegistryGpgKeysKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeRegistryGpgKeysKeysOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_gpg_keys tfe_registry_gpg_keys}
*/
export declare class DataTfeRegistryGpgKeys extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_registry_gpg_keys";
    /**
    * Generates CDKTF code for importing a DataTfeRegistryGpgKeys resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeRegistryGpgKeys to import
    * @param importFromId The id of the existing DataTfeRegistryGpgKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_gpg_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeRegistryGpgKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_gpg_keys tfe_registry_gpg_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeRegistryGpgKeysConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeRegistryGpgKeysConfig);
    get id(): string;
    private _keys;
    get keys(): DataTfeRegistryGpgKeysKeysList;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
