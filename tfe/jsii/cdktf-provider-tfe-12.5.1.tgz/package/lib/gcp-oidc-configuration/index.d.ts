/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GcpOidcConfigurationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the organization to which the TFE GCP OIDC configuration belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/gcp_oidc_configuration#organization GcpOidcConfiguration#organization}
    */
    readonly organization?: string;
    /**
    * The GCP Project containing the workload provider and service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/gcp_oidc_configuration#project_number GcpOidcConfiguration#project_number}
    */
    readonly projectNumber: string;
    /**
    * The email of your GCP service account, with permissions to encrypt and decrypt using a Cloud KMS key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/gcp_oidc_configuration#service_account_email GcpOidcConfiguration#service_account_email}
    */
    readonly serviceAccountEmail: string;
    /**
    * The fully qualified workload provider path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/gcp_oidc_configuration#workload_provider_name GcpOidcConfiguration#workload_provider_name}
    */
    readonly workloadProviderName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/gcp_oidc_configuration tfe_gcp_oidc_configuration}
*/
export declare class GcpOidcConfiguration extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_gcp_oidc_configuration";
    /**
    * Generates CDKTF code for importing a GcpOidcConfiguration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GcpOidcConfiguration to import
    * @param importFromId The id of the existing GcpOidcConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/gcp_oidc_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GcpOidcConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/gcp_oidc_configuration tfe_gcp_oidc_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GcpOidcConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: GcpOidcConfigurationConfig);
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _projectNumber?;
    get projectNumber(): string;
    set projectNumber(value: string);
    get projectNumberInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
    private _workloadProviderName?;
    get workloadProviderName(): string;
    set workloadProviderName(value: string);
    get workloadProviderNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
