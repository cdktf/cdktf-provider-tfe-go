/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface HyokConfigurationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the agent-pool to associate with the HYOK configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#agent_pool_id HyokConfiguration#agent_pool_id}
    */
    readonly agentPoolId: string;
    /**
    * Refers to the name of your key encryption key stored in your key management service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#kek_id HyokConfiguration#kek_id}
    */
    readonly kekId: string;
    /**
    * Label for the HYOK configuration to be used within HCP Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#name HyokConfiguration#name}
    */
    readonly name: string;
    /**
    * The ID of the TFE OIDC configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#oidc_configuration_id HyokConfiguration#oidc_configuration_id}
    */
    readonly oidcConfigurationId: string;
    /**
    * The type of the TFE OIDC configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#oidc_configuration_type HyokConfiguration#oidc_configuration_type}
    */
    readonly oidcConfigurationType: string;
    /**
    * Name of the organization to which the TFE HYOK configuration belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#organization HyokConfiguration#organization}
    */
    readonly organization?: string;
    /**
    * kms_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#kms_options HyokConfiguration#kms_options}
    */
    readonly kmsOptions?: HyokConfigurationKmsOptions;
}
export interface HyokConfigurationKmsOptions {
    /**
    * The location in which the GCP key ring exists.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#key_location HyokConfiguration#key_location}
    */
    readonly keyLocation?: string;
    /**
    * The AWS region where your key is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#key_region HyokConfiguration#key_region}
    */
    readonly keyRegion?: string;
    /**
    * The root resource for Google Cloud KMS keys and key versions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#key_ring_id HyokConfiguration#key_ring_id}
    */
    readonly keyRingId?: string;
}
export declare function hyokConfigurationKmsOptionsToTerraform(struct?: HyokConfigurationKmsOptions | cdktf.IResolvable): any;
export declare function hyokConfigurationKmsOptionsToHclTerraform(struct?: HyokConfigurationKmsOptions | cdktf.IResolvable): any;
export declare class HyokConfigurationKmsOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HyokConfigurationKmsOptions | cdktf.IResolvable | undefined;
    set internalValue(value: HyokConfigurationKmsOptions | cdktf.IResolvable | undefined);
    private _keyLocation?;
    get keyLocation(): string;
    set keyLocation(value: string);
    resetKeyLocation(): void;
    get keyLocationInput(): string | undefined;
    private _keyRegion?;
    get keyRegion(): string;
    set keyRegion(value: string);
    resetKeyRegion(): void;
    get keyRegionInput(): string | undefined;
    private _keyRingId?;
    get keyRingId(): string;
    set keyRingId(value: string);
    resetKeyRingId(): void;
    get keyRingIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration tfe_hyok_configuration}
*/
export declare class HyokConfiguration extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_hyok_configuration";
    /**
    * Generates CDKTF code for importing a HyokConfiguration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HyokConfiguration to import
    * @param importFromId The id of the existing HyokConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HyokConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/hyok_configuration tfe_hyok_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HyokConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: HyokConfigurationConfig);
    private _agentPoolId?;
    get agentPoolId(): string;
    set agentPoolId(value: string);
    get agentPoolIdInput(): string | undefined;
    get id(): string;
    private _kekId?;
    get kekId(): string;
    set kekId(value: string);
    get kekIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _oidcConfigurationId?;
    get oidcConfigurationId(): string;
    set oidcConfigurationId(value: string);
    get oidcConfigurationIdInput(): string | undefined;
    private _oidcConfigurationType?;
    get oidcConfigurationType(): string;
    set oidcConfigurationType(value: string);
    get oidcConfigurationTypeInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _kmsOptions;
    get kmsOptions(): HyokConfigurationKmsOptionsOutputReference;
    putKmsOptions(value: HyokConfigurationKmsOptions): void;
    resetKmsOptions(): void;
    get kmsOptionsInput(): cdktf.IResolvable | HyokConfigurationKmsOptions | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
