/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WorkspaceRunConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#id WorkspaceRun#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#workspace_id WorkspaceRun#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * apply block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#apply WorkspaceRun#apply}
    */
    readonly apply?: WorkspaceRunApply;
    /**
    * destroy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#destroy WorkspaceRun#destroy}
    */
    readonly destroy?: WorkspaceRunDestroy;
}
export interface WorkspaceRunApply {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#manual_confirm WorkspaceRun#manual_confirm}
    */
    readonly manualConfirm: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry WorkspaceRun#retry}
    */
    readonly retry?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry_attempts WorkspaceRun#retry_attempts}
    */
    readonly retryAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry_backoff_max WorkspaceRun#retry_backoff_max}
    */
    readonly retryBackoffMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry_backoff_min WorkspaceRun#retry_backoff_min}
    */
    readonly retryBackoffMin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#wait_for_run WorkspaceRun#wait_for_run}
    */
    readonly waitForRun?: boolean | cdktf.IResolvable;
}
export declare function workspaceRunApplyToTerraform(struct?: WorkspaceRunApplyOutputReference | WorkspaceRunApply): any;
export declare function workspaceRunApplyToHclTerraform(struct?: WorkspaceRunApplyOutputReference | WorkspaceRunApply): any;
export declare class WorkspaceRunApplyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceRunApply | undefined;
    set internalValue(value: WorkspaceRunApply | undefined);
    private _manualConfirm?;
    get manualConfirm(): boolean | cdktf.IResolvable;
    set manualConfirm(value: boolean | cdktf.IResolvable);
    get manualConfirmInput(): boolean | cdktf.IResolvable | undefined;
    private _retry?;
    get retry(): boolean | cdktf.IResolvable;
    set retry(value: boolean | cdktf.IResolvable);
    resetRetry(): void;
    get retryInput(): boolean | cdktf.IResolvable | undefined;
    private _retryAttempts?;
    get retryAttempts(): number;
    set retryAttempts(value: number);
    resetRetryAttempts(): void;
    get retryAttemptsInput(): number | undefined;
    private _retryBackoffMax?;
    get retryBackoffMax(): number;
    set retryBackoffMax(value: number);
    resetRetryBackoffMax(): void;
    get retryBackoffMaxInput(): number | undefined;
    private _retryBackoffMin?;
    get retryBackoffMin(): number;
    set retryBackoffMin(value: number);
    resetRetryBackoffMin(): void;
    get retryBackoffMinInput(): number | undefined;
    private _waitForRun?;
    get waitForRun(): boolean | cdktf.IResolvable;
    set waitForRun(value: boolean | cdktf.IResolvable);
    resetWaitForRun(): void;
    get waitForRunInput(): boolean | cdktf.IResolvable | undefined;
}
export interface WorkspaceRunDestroy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#manual_confirm WorkspaceRun#manual_confirm}
    */
    readonly manualConfirm: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry WorkspaceRun#retry}
    */
    readonly retry?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry_attempts WorkspaceRun#retry_attempts}
    */
    readonly retryAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry_backoff_max WorkspaceRun#retry_backoff_max}
    */
    readonly retryBackoffMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#retry_backoff_min WorkspaceRun#retry_backoff_min}
    */
    readonly retryBackoffMin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#wait_for_run WorkspaceRun#wait_for_run}
    */
    readonly waitForRun?: boolean | cdktf.IResolvable;
}
export declare function workspaceRunDestroyToTerraform(struct?: WorkspaceRunDestroyOutputReference | WorkspaceRunDestroy): any;
export declare function workspaceRunDestroyToHclTerraform(struct?: WorkspaceRunDestroyOutputReference | WorkspaceRunDestroy): any;
export declare class WorkspaceRunDestroyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceRunDestroy | undefined;
    set internalValue(value: WorkspaceRunDestroy | undefined);
    private _manualConfirm?;
    get manualConfirm(): boolean | cdktf.IResolvable;
    set manualConfirm(value: boolean | cdktf.IResolvable);
    get manualConfirmInput(): boolean | cdktf.IResolvable | undefined;
    private _retry?;
    get retry(): boolean | cdktf.IResolvable;
    set retry(value: boolean | cdktf.IResolvable);
    resetRetry(): void;
    get retryInput(): boolean | cdktf.IResolvable | undefined;
    private _retryAttempts?;
    get retryAttempts(): number;
    set retryAttempts(value: number);
    resetRetryAttempts(): void;
    get retryAttemptsInput(): number | undefined;
    private _retryBackoffMax?;
    get retryBackoffMax(): number;
    set retryBackoffMax(value: number);
    resetRetryBackoffMax(): void;
    get retryBackoffMaxInput(): number | undefined;
    private _retryBackoffMin?;
    get retryBackoffMin(): number;
    set retryBackoffMin(value: number);
    resetRetryBackoffMin(): void;
    get retryBackoffMinInput(): number | undefined;
    private _waitForRun?;
    get waitForRun(): boolean | cdktf.IResolvable;
    set waitForRun(value: boolean | cdktf.IResolvable);
    resetWaitForRun(): void;
    get waitForRunInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run tfe_workspace_run}
*/
export declare class WorkspaceRun extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_workspace_run";
    /**
    * Generates CDKTF code for importing a WorkspaceRun resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceRun to import
    * @param importFromId The id of the existing WorkspaceRun that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceRun to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/workspace_run tfe_workspace_run} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceRunConfig
    */
    constructor(scope: Construct, id: string, config: WorkspaceRunConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _apply;
    get apply(): WorkspaceRunApplyOutputReference;
    putApply(value: WorkspaceRunApply): void;
    resetApply(): void;
    get applyInput(): WorkspaceRunApply | undefined;
    private _destroy;
    get destroy(): WorkspaceRunDestroyOutputReference;
    putDestroy(value: WorkspaceRunDestroy): void;
    resetDestroy(): void;
    get destroyInput(): WorkspaceRunDestroy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
