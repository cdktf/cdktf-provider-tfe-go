/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PolicySetParameterConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter#key PolicySetParameter#key}
    */
    readonly key: string;
    /**
    * The ID of the policy set that owns the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter#policy_set_id PolicySetParameter#policy_set_id}
    */
    readonly policySetId: string;
    /**
    * Whether the value is sensitive. If true then the parameter is written once and not visible thereafter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter#sensitive PolicySetParameter#sensitive}
    */
    readonly sensitive?: boolean | cdktf.IResolvable;
    /**
    * Value of the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter#value PolicySetParameter#value}
    */
    readonly value?: string;
    /**
    * Value of the parameter in write-only mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter#value_wo PolicySetParameter#value_wo}
    */
    readonly valueWo?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter tfe_policy_set_parameter}
*/
export declare class PolicySetParameter extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_policy_set_parameter";
    /**
    * Generates CDKTF code for importing a PolicySetParameter resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicySetParameter to import
    * @param importFromId The id of the existing PolicySetParameter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicySetParameter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/policy_set_parameter tfe_policy_set_parameter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicySetParameterConfig
    */
    constructor(scope: Construct, id: string, config: PolicySetParameterConfig);
    get id(): string;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _policySetId?;
    get policySetId(): string;
    set policySetId(value: string);
    get policySetIdInput(): string | undefined;
    private _sensitive?;
    get sensitive(): boolean | cdktf.IResolvable;
    set sensitive(value: boolean | cdktf.IResolvable);
    resetSensitive(): void;
    get sensitiveInput(): boolean | cdktf.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueWo?;
    get valueWo(): string;
    set valueWo(value: string);
    resetValueWo(): void;
    get valueWoInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
