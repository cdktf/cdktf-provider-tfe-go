/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TerraformVersionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#archs TerraformVersion#archs}
    */
    readonly archs?: TerraformVersionArchs[] | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#beta TerraformVersion#beta}
    */
    readonly beta?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#deprecated TerraformVersion#deprecated}
    */
    readonly deprecated?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#deprecated_reason TerraformVersion#deprecated_reason}
    */
    readonly deprecatedReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#enabled TerraformVersion#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#official TerraformVersion#official}
    */
    readonly official?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#sha TerraformVersion#sha}
    */
    readonly sha?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#url TerraformVersion#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#version TerraformVersion#version}
    */
    readonly version: string;
}
export interface TerraformVersionArchs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#arch TerraformVersion#arch}
    */
    readonly arch: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#os TerraformVersion#os}
    */
    readonly os: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#sha TerraformVersion#sha}
    */
    readonly sha: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#url TerraformVersion#url}
    */
    readonly url: string;
}
export declare function terraformVersionArchsToTerraform(struct?: TerraformVersionArchs | cdktf.IResolvable): any;
export declare function terraformVersionArchsToHclTerraform(struct?: TerraformVersionArchs | cdktf.IResolvable): any;
export declare class TerraformVersionArchsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TerraformVersionArchs | cdktf.IResolvable | undefined;
    set internalValue(value: TerraformVersionArchs | cdktf.IResolvable | undefined);
    private _arch?;
    get arch(): string;
    set arch(value: string);
    get archInput(): string | undefined;
    private _os?;
    get os(): string;
    set os(value: string);
    get osInput(): string | undefined;
    private _sha?;
    get sha(): string;
    set sha(value: string);
    get shaInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class TerraformVersionArchsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TerraformVersionArchs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TerraformVersionArchsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version tfe_terraform_version}
*/
export declare class TerraformVersion extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_terraform_version";
    /**
    * Generates CDKTF code for importing a TerraformVersion resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TerraformVersion to import
    * @param importFromId The id of the existing TerraformVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TerraformVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/terraform_version tfe_terraform_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TerraformVersionConfig
    */
    constructor(scope: Construct, id: string, config: TerraformVersionConfig);
    private _archs;
    get archs(): TerraformVersionArchsList;
    putArchs(value: TerraformVersionArchs[] | cdktf.IResolvable): void;
    resetArchs(): void;
    get archsInput(): cdktf.IResolvable | TerraformVersionArchs[] | undefined;
    private _beta?;
    get beta(): boolean | cdktf.IResolvable;
    set beta(value: boolean | cdktf.IResolvable);
    resetBeta(): void;
    get betaInput(): boolean | cdktf.IResolvable | undefined;
    private _deprecated?;
    get deprecated(): boolean | cdktf.IResolvable;
    set deprecated(value: boolean | cdktf.IResolvable);
    resetDeprecated(): void;
    get deprecatedInput(): boolean | cdktf.IResolvable | undefined;
    private _deprecatedReason?;
    get deprecatedReason(): string;
    set deprecatedReason(value: string);
    resetDeprecatedReason(): void;
    get deprecatedReasonInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _official?;
    get official(): boolean | cdktf.IResolvable;
    set official(value: boolean | cdktf.IResolvable);
    resetOfficial(): void;
    get officialInput(): boolean | cdktf.IResolvable | undefined;
    private _sha?;
    get sha(): string;
    set sha(value: string);
    resetSha(): void;
    get shaInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
