/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface OrganizationDefaultSettingsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_default_settings#default_agent_pool_id OrganizationDefaultSettings#default_agent_pool_id}
    */
    readonly defaultAgentPoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_default_settings#default_execution_mode OrganizationDefaultSettings#default_execution_mode}
    */
    readonly defaultExecutionMode: string;
    /**
    * The name of the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_default_settings#organization OrganizationDefaultSettings#organization}
    */
    readonly organization?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_default_settings tfe_organization_default_settings}
*/
export declare class OrganizationDefaultSettings extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_organization_default_settings";
    /**
    * Generates CDKTF code for importing a OrganizationDefaultSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrganizationDefaultSettings to import
    * @param importFromId The id of the existing OrganizationDefaultSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_default_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrganizationDefaultSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_default_settings tfe_organization_default_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationDefaultSettingsConfig
    */
    constructor(scope: Construct, id: string, config: OrganizationDefaultSettingsConfig);
    private _defaultAgentPoolId?;
    get defaultAgentPoolId(): string;
    set defaultAgentPoolId(value: string);
    resetDefaultAgentPoolId(): void;
    get defaultAgentPoolIdInput(): string | undefined;
    private _defaultExecutionMode?;
    get defaultExecutionMode(): string;
    set defaultExecutionMode(value: string);
    get defaultExecutionModeInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
