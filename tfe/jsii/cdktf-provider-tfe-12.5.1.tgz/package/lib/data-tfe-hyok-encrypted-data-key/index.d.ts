/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeHyokEncryptedDataKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the HYOK encrypted data key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/hyok_encrypted_data_key#id DataTfeHyokEncryptedDataKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/hyok_encrypted_data_key tfe_hyok_encrypted_data_key}
*/
export declare class DataTfeHyokEncryptedDataKey extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_hyok_encrypted_data_key";
    /**
    * Generates CDKTF code for importing a DataTfeHyokEncryptedDataKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeHyokEncryptedDataKey to import
    * @param importFromId The id of the existing DataTfeHyokEncryptedDataKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/hyok_encrypted_data_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeHyokEncryptedDataKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/hyok_encrypted_data_key tfe_hyok_encrypted_data_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeHyokEncryptedDataKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeHyokEncryptedDataKeyConfig);
    get createdAt(): string;
    get customerKeyName(): string;
    get encryptedDek(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
