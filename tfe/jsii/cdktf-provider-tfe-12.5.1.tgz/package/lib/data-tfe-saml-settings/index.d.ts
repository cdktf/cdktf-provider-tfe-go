/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeSamlSettingsConfig extends cdktf.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/saml_settings tfe_saml_settings}
*/
export declare class DataTfeSamlSettings extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_saml_settings";
    /**
    * Generates CDKTF code for importing a DataTfeSamlSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeSamlSettings to import
    * @param importFromId The id of the existing DataTfeSamlSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/saml_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeSamlSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/saml_settings tfe_saml_settings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeSamlSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeSamlSettingsConfig);
    get acsConsumerUrl(): string;
    get attrGroups(): string;
    get attrSiteAdmin(): string;
    get attrUsername(): string;
    get authnRequestsSigned(): cdktf.IResolvable;
    get certificate(): string;
    get debug(): cdktf.IResolvable;
    get enabled(): cdktf.IResolvable;
    get id(): string;
    get idpCert(): string;
    get metadataUrl(): string;
    get oldIdpCert(): string;
    get privateKey(): string;
    get signatureDigestMethod(): string;
    get signatureSigningMethod(): string;
    get siteAdminRole(): string;
    get sloEndpointUrl(): string;
    get ssoApiTokenSessionTimeout(): number;
    get ssoEndpointUrl(): string;
    get teamManagementEnabled(): cdktf.IResolvable;
    get wantAssertionsSigned(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
