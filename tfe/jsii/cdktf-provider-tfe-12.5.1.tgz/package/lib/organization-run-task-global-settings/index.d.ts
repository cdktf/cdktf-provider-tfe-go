/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface OrganizationRunTaskGlobalSettingsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Whether the run task will be applied globally
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_run_task_global_settings#enabled OrganizationRunTaskGlobalSettings#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * The enforcement level of the global task. Valid values are `advisory` and `mandatory`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_run_task_global_settings#enforcement_level OrganizationRunTaskGlobalSettings#enforcement_level}
    */
    readonly enforcementLevel: string;
    /**
    * Which stages the task will run in. Valid values are `pre_plan`, `post_plan`, `pre_apply` and `post_apply`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_run_task_global_settings#stages OrganizationRunTaskGlobalSettings#stages}
    */
    readonly stages: string[];
    /**
    * The id of the run task.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_run_task_global_settings#task_id OrganizationRunTaskGlobalSettings#task_id}
    */
    readonly taskId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_run_task_global_settings tfe_organization_run_task_global_settings}
*/
export declare class OrganizationRunTaskGlobalSettings extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_organization_run_task_global_settings";
    /**
    * Generates CDKTF code for importing a OrganizationRunTaskGlobalSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrganizationRunTaskGlobalSettings to import
    * @param importFromId The id of the existing OrganizationRunTaskGlobalSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_run_task_global_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrganizationRunTaskGlobalSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/organization_run_task_global_settings tfe_organization_run_task_global_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationRunTaskGlobalSettingsConfig
    */
    constructor(scope: Construct, id: string, config: OrganizationRunTaskGlobalSettingsConfig);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _enforcementLevel?;
    get enforcementLevel(): string;
    set enforcementLevel(value: string);
    get enforcementLevelInput(): string | undefined;
    get id(): string;
    private _stages?;
    get stages(): string[];
    set stages(value: string[]);
    get stagesInput(): string[] | undefined;
    private _taskId?;
    get taskId(): string;
    set taskId(value: string);
    get taskIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
