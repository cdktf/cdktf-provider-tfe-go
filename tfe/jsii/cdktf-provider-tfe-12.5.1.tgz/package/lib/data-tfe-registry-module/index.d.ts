/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeRegistryModuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the module provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#module_provider DataTfeRegistryModule#module_provider}
    */
    readonly moduleProvider: string;
    /**
    * Name of the module.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#name DataTfeRegistryModule#name}
    */
    readonly name: string;
    /**
    * The namespace of the no-code module. Uses organization name if not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#namespace DataTfeRegistryModule#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#organization DataTfeRegistryModule#organization}
    */
    readonly organization: string;
    /**
    * Name of the registry. Valid options: "public", "private". Defaults to "private".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#registry_name DataTfeRegistryModule#registry_name}
    */
    readonly registryName?: string;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#permissions DataTfeRegistryModule#permissions}
    */
    readonly permissions?: DataTfeRegistryModulePermissions[] | cdktf.IResolvable;
    /**
    * test_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#test_config DataTfeRegistryModule#test_config}
    */
    readonly testConfig?: DataTfeRegistryModuleTestConfig[] | cdktf.IResolvable;
    /**
    * vcs_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#vcs_repo DataTfeRegistryModule#vcs_repo}
    */
    readonly vcsRepo?: DataTfeRegistryModuleVcsRepo[] | cdktf.IResolvable;
    /**
    * version_statuses block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#version_statuses DataTfeRegistryModule#version_statuses}
    */
    readonly versionStatuses?: DataTfeRegistryModuleVersionStatuses[] | cdktf.IResolvable;
}
export interface DataTfeRegistryModulePermissions {
}
export declare function dataTfeRegistryModulePermissionsToTerraform(struct?: DataTfeRegistryModulePermissions | cdktf.IResolvable): any;
export declare function dataTfeRegistryModulePermissionsToHclTerraform(struct?: DataTfeRegistryModulePermissions | cdktf.IResolvable): any;
export declare class DataTfeRegistryModulePermissionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeRegistryModulePermissions | cdktf.IResolvable | undefined;
    set internalValue(value: DataTfeRegistryModulePermissions | cdktf.IResolvable | undefined);
    get canDelete(): cdktf.IResolvable;
    get canResync(): cdktf.IResolvable;
    get canRetry(): cdktf.IResolvable;
}
export declare class DataTfeRegistryModulePermissionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataTfeRegistryModulePermissions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeRegistryModulePermissionsOutputReference;
}
export interface DataTfeRegistryModuleTestConfig {
}
export declare function dataTfeRegistryModuleTestConfigToTerraform(struct?: DataTfeRegistryModuleTestConfig | cdktf.IResolvable): any;
export declare function dataTfeRegistryModuleTestConfigToHclTerraform(struct?: DataTfeRegistryModuleTestConfig | cdktf.IResolvable): any;
export declare class DataTfeRegistryModuleTestConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeRegistryModuleTestConfig | cdktf.IResolvable | undefined;
    set internalValue(value: DataTfeRegistryModuleTestConfig | cdktf.IResolvable | undefined);
    get testsEnabled(): cdktf.IResolvable;
}
export declare class DataTfeRegistryModuleTestConfigList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataTfeRegistryModuleTestConfig[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeRegistryModuleTestConfigOutputReference;
}
export interface DataTfeRegistryModuleVcsRepo {
}
export declare function dataTfeRegistryModuleVcsRepoToTerraform(struct?: DataTfeRegistryModuleVcsRepo | cdktf.IResolvable): any;
export declare function dataTfeRegistryModuleVcsRepoToHclTerraform(struct?: DataTfeRegistryModuleVcsRepo | cdktf.IResolvable): any;
export declare class DataTfeRegistryModuleVcsRepoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeRegistryModuleVcsRepo | cdktf.IResolvable | undefined;
    set internalValue(value: DataTfeRegistryModuleVcsRepo | cdktf.IResolvable | undefined);
    get branch(): string;
    get displayIdentifier(): string;
    get githubAppInstallationId(): string;
    get identifier(): string;
    get ingressSubmodules(): cdktf.IResolvable;
    get oauthTokenId(): string;
    get repositoryHttpUrl(): string;
    get serviceProvider(): string;
    get sourceDirectory(): string;
    get tagPrefix(): string;
    get tags(): cdktf.IResolvable;
    get tagsRegex(): string;
    get webhookUrl(): string;
}
export declare class DataTfeRegistryModuleVcsRepoList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataTfeRegistryModuleVcsRepo[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeRegistryModuleVcsRepoOutputReference;
}
export interface DataTfeRegistryModuleVersionStatuses {
}
export declare function dataTfeRegistryModuleVersionStatusesToTerraform(struct?: DataTfeRegistryModuleVersionStatuses | cdktf.IResolvable): any;
export declare function dataTfeRegistryModuleVersionStatusesToHclTerraform(struct?: DataTfeRegistryModuleVersionStatuses | cdktf.IResolvable): any;
export declare class DataTfeRegistryModuleVersionStatusesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeRegistryModuleVersionStatuses | cdktf.IResolvable | undefined;
    set internalValue(value: DataTfeRegistryModuleVersionStatuses | cdktf.IResolvable | undefined);
    get error(): string;
    get status(): string;
    get version(): string;
}
export declare class DataTfeRegistryModuleVersionStatusesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataTfeRegistryModuleVersionStatuses[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeRegistryModuleVersionStatusesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module tfe_registry_module}
*/
export declare class DataTfeRegistryModule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_registry_module";
    /**
    * Generates CDKTF code for importing a DataTfeRegistryModule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeRegistryModule to import
    * @param importFromId The id of the existing DataTfeRegistryModule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeRegistryModule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_module tfe_registry_module} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeRegistryModuleConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeRegistryModuleConfig);
    get createdAt(): string;
    get id(): string;
    private _moduleProvider?;
    get moduleProvider(): string;
    set moduleProvider(value: string);
    get moduleProviderInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get noCode(): cdktf.IResolvable;
    get noCodeModuleId(): string;
    get noCodeModuleSource(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get publishingMechanism(): string;
    private _registryName?;
    get registryName(): string;
    set registryName(value: string);
    resetRegistryName(): void;
    get registryNameInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    private _permissions;
    get permissions(): DataTfeRegistryModulePermissionsList;
    putPermissions(value: DataTfeRegistryModulePermissions[] | cdktf.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktf.IResolvable | DataTfeRegistryModulePermissions[] | undefined;
    private _testConfig;
    get testConfig(): DataTfeRegistryModuleTestConfigList;
    putTestConfig(value: DataTfeRegistryModuleTestConfig[] | cdktf.IResolvable): void;
    resetTestConfig(): void;
    get testConfigInput(): cdktf.IResolvable | DataTfeRegistryModuleTestConfig[] | undefined;
    private _vcsRepo;
    get vcsRepo(): DataTfeRegistryModuleVcsRepoList;
    putVcsRepo(value: DataTfeRegistryModuleVcsRepo[] | cdktf.IResolvable): void;
    resetVcsRepo(): void;
    get vcsRepoInput(): cdktf.IResolvable | DataTfeRegistryModuleVcsRepo[] | undefined;
    private _versionStatuses;
    get versionStatuses(): DataTfeRegistryModuleVersionStatusesList;
    putVersionStatuses(value: DataTfeRegistryModuleVersionStatuses[] | cdktf.IResolvable): void;
    resetVersionStatuses(): void;
    get versionStatusesInput(): cdktf.IResolvable | DataTfeRegistryModuleVersionStatuses[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
