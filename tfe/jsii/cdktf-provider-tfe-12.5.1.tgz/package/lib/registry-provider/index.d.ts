/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RegistryProviderConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_provider#name RegistryProvider#name}
    */
    readonly name: string;
    /**
    * The namespace of the provider. For private providers this is the same as the oraganization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_provider#namespace RegistryProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the organization. If omitted, organization must be defined in the provider config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_provider#organization RegistryProvider#organization}
    */
    readonly organization?: string;
    /**
    * Whether this is a publicly maintained provider or private. Must be either `public` or `private`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_provider#registry_name RegistryProvider#registry_name}
    */
    readonly registryName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_provider tfe_registry_provider}
*/
export declare class RegistryProvider extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_registry_provider";
    /**
    * Generates CDKTF code for importing a RegistryProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RegistryProvider to import
    * @param importFromId The id of the existing RegistryProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RegistryProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_provider tfe_registry_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RegistryProviderConfig
    */
    constructor(scope: Construct, id: string, config: RegistryProviderConfig);
    get createdAt(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _registryName?;
    get registryName(): string;
    set registryName(value: string);
    resetRegistryName(): void;
    get registryNameInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
