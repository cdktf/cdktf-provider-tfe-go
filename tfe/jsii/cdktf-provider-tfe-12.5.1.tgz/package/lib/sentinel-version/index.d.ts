/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SentinelVersionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#archs SentinelVersion#archs}
    */
    readonly archs?: SentinelVersionArchs[] | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#beta SentinelVersion#beta}
    */
    readonly beta?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#deprecated SentinelVersion#deprecated}
    */
    readonly deprecated?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#deprecated_reason SentinelVersion#deprecated_reason}
    */
    readonly deprecatedReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#enabled SentinelVersion#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#official SentinelVersion#official}
    */
    readonly official?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#sha SentinelVersion#sha}
    */
    readonly sha?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#url SentinelVersion#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#version SentinelVersion#version}
    */
    readonly version: string;
}
export interface SentinelVersionArchs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#arch SentinelVersion#arch}
    */
    readonly arch: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#os SentinelVersion#os}
    */
    readonly os: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#sha SentinelVersion#sha}
    */
    readonly sha: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#url SentinelVersion#url}
    */
    readonly url: string;
}
export declare function sentinelVersionArchsToTerraform(struct?: SentinelVersionArchs | cdktf.IResolvable): any;
export declare function sentinelVersionArchsToHclTerraform(struct?: SentinelVersionArchs | cdktf.IResolvable): any;
export declare class SentinelVersionArchsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SentinelVersionArchs | cdktf.IResolvable | undefined;
    set internalValue(value: SentinelVersionArchs | cdktf.IResolvable | undefined);
    private _arch?;
    get arch(): string;
    set arch(value: string);
    get archInput(): string | undefined;
    private _os?;
    get os(): string;
    set os(value: string);
    get osInput(): string | undefined;
    private _sha?;
    get sha(): string;
    set sha(value: string);
    get shaInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class SentinelVersionArchsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SentinelVersionArchs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SentinelVersionArchsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version tfe_sentinel_version}
*/
export declare class SentinelVersion extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_sentinel_version";
    /**
    * Generates CDKTF code for importing a SentinelVersion resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SentinelVersion to import
    * @param importFromId The id of the existing SentinelVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SentinelVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/sentinel_version tfe_sentinel_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SentinelVersionConfig
    */
    constructor(scope: Construct, id: string, config: SentinelVersionConfig);
    private _archs;
    get archs(): SentinelVersionArchsList;
    putArchs(value: SentinelVersionArchs[] | cdktf.IResolvable): void;
    resetArchs(): void;
    get archsInput(): cdktf.IResolvable | SentinelVersionArchs[] | undefined;
    private _beta?;
    get beta(): boolean | cdktf.IResolvable;
    set beta(value: boolean | cdktf.IResolvable);
    resetBeta(): void;
    get betaInput(): boolean | cdktf.IResolvable | undefined;
    private _deprecated?;
    get deprecated(): boolean | cdktf.IResolvable;
    set deprecated(value: boolean | cdktf.IResolvable);
    resetDeprecated(): void;
    get deprecatedInput(): boolean | cdktf.IResolvable | undefined;
    private _deprecatedReason?;
    get deprecatedReason(): string;
    set deprecatedReason(value: string);
    resetDeprecatedReason(): void;
    get deprecatedReasonInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _official?;
    get official(): boolean | cdktf.IResolvable;
    set official(value: boolean | cdktf.IResolvable);
    resetOfficial(): void;
    get officialInput(): boolean | cdktf.IResolvable | undefined;
    private _sha?;
    get sha(): string;
    set sha(value: string);
    resetSha(): void;
    get shaInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
