/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AuditTrailTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The time when the audit trail token will expire. This must be a valid ISO8601 timestamp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/audit_trail_token#expired_at AuditTrailToken#expired_at}
    */
    readonly expiredAt?: string;
    /**
    * When set to true will force the audit trail token to be recreated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/audit_trail_token#force_regenerate AuditTrailToken#force_regenerate}
    */
    readonly forceRegenerate?: boolean | cdktf.IResolvable;
    /**
    * Name of the organization. If omitted, organization must be defined in the provider config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/audit_trail_token#organization AuditTrailToken#organization}
    */
    readonly organization?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/audit_trail_token tfe_audit_trail_token}
*/
export declare class AuditTrailToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_audit_trail_token";
    /**
    * Generates CDKTF code for importing a AuditTrailToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuditTrailToken to import
    * @param importFromId The id of the existing AuditTrailToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/audit_trail_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuditTrailToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/audit_trail_token tfe_audit_trail_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuditTrailTokenConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AuditTrailTokenConfig);
    private _expiredAt?;
    get expiredAt(): string;
    set expiredAt(value: string);
    resetExpiredAt(): void;
    get expiredAtInput(): string | undefined;
    private _forceRegenerate?;
    get forceRegenerate(): boolean | cdktf.IResolvable;
    set forceRegenerate(value: boolean | cdktf.IResolvable);
    resetForceRegenerate(): void;
    get forceRegenerateInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    get token(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
