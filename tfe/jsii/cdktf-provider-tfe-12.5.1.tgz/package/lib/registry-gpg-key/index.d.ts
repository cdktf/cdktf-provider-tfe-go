/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RegistryGpgKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * ASCII-armored representation of the GPG key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_gpg_key#ascii_armor RegistryGpgKey#ascii_armor}
    */
    readonly asciiArmor: string;
    /**
    * Name of the organization. If omitted, organization must be defined in the provider config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_gpg_key#organization RegistryGpgKey#organization}
    */
    readonly organization?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_gpg_key tfe_registry_gpg_key}
*/
export declare class RegistryGpgKey extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_registry_gpg_key";
    /**
    * Generates CDKTF code for importing a RegistryGpgKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RegistryGpgKey to import
    * @param importFromId The id of the existing RegistryGpgKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_gpg_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RegistryGpgKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_gpg_key tfe_registry_gpg_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RegistryGpgKeyConfig
    */
    constructor(scope: Construct, id: string, config: RegistryGpgKeyConfig);
    private _asciiArmor?;
    get asciiArmor(): string;
    set asciiArmor(value: string);
    get asciiArmorInput(): string | undefined;
    get createdAt(): string;
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
