/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RegistryModuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#id RegistryModule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#initial_version RegistryModule#initial_version}
    */
    readonly initialVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#module_provider RegistryModule#module_provider}
    */
    readonly moduleProvider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#name RegistryModule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#namespace RegistryModule#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#no_code RegistryModule#no_code}
    */
    readonly noCode?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#organization RegistryModule#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#registry_name RegistryModule#registry_name}
    */
    readonly registryName?: string;
    /**
    * test_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#test_config RegistryModule#test_config}
    */
    readonly testConfig?: RegistryModuleTestConfig[] | cdktf.IResolvable;
    /**
    * vcs_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#vcs_repo RegistryModule#vcs_repo}
    */
    readonly vcsRepo?: RegistryModuleVcsRepo;
}
export interface RegistryModuleTestConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#agent_execution_mode RegistryModule#agent_execution_mode}
    */
    readonly agentExecutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#agent_pool_id RegistryModule#agent_pool_id}
    */
    readonly agentPoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#tests_enabled RegistryModule#tests_enabled}
    */
    readonly testsEnabled?: boolean | cdktf.IResolvable;
}
export declare function registryModuleTestConfigToTerraform(struct?: RegistryModuleTestConfig | cdktf.IResolvable): any;
export declare function registryModuleTestConfigToHclTerraform(struct?: RegistryModuleTestConfig | cdktf.IResolvable): any;
export declare class RegistryModuleTestConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RegistryModuleTestConfig | cdktf.IResolvable | undefined;
    set internalValue(value: RegistryModuleTestConfig | cdktf.IResolvable | undefined);
    private _agentExecutionMode?;
    get agentExecutionMode(): string;
    set agentExecutionMode(value: string);
    resetAgentExecutionMode(): void;
    get agentExecutionModeInput(): string | undefined;
    private _agentPoolId?;
    get agentPoolId(): string;
    set agentPoolId(value: string);
    resetAgentPoolId(): void;
    get agentPoolIdInput(): string | undefined;
    private _testsEnabled?;
    get testsEnabled(): boolean | cdktf.IResolvable;
    set testsEnabled(value: boolean | cdktf.IResolvable);
    resetTestsEnabled(): void;
    get testsEnabledInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RegistryModuleTestConfigList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RegistryModuleTestConfig[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RegistryModuleTestConfigOutputReference;
}
export interface RegistryModuleVcsRepo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#branch RegistryModule#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#display_identifier RegistryModule#display_identifier}
    */
    readonly displayIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#github_app_installation_id RegistryModule#github_app_installation_id}
    */
    readonly githubAppInstallationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#identifier RegistryModule#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#oauth_token_id RegistryModule#oauth_token_id}
    */
    readonly oauthTokenId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#source_directory RegistryModule#source_directory}
    */
    readonly sourceDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#tag_prefix RegistryModule#tag_prefix}
    */
    readonly tagPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#tags RegistryModule#tags}
    */
    readonly tags?: boolean | cdktf.IResolvable;
}
export declare function registryModuleVcsRepoToTerraform(struct?: RegistryModuleVcsRepoOutputReference | RegistryModuleVcsRepo): any;
export declare function registryModuleVcsRepoToHclTerraform(struct?: RegistryModuleVcsRepoOutputReference | RegistryModuleVcsRepo): any;
export declare class RegistryModuleVcsRepoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RegistryModuleVcsRepo | undefined;
    set internalValue(value: RegistryModuleVcsRepo | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _displayIdentifier?;
    get displayIdentifier(): string;
    set displayIdentifier(value: string);
    get displayIdentifierInput(): string | undefined;
    private _githubAppInstallationId?;
    get githubAppInstallationId(): string;
    set githubAppInstallationId(value: string);
    resetGithubAppInstallationId(): void;
    get githubAppInstallationIdInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _oauthTokenId?;
    get oauthTokenId(): string;
    set oauthTokenId(value: string);
    resetOauthTokenId(): void;
    get oauthTokenIdInput(): string | undefined;
    private _sourceDirectory?;
    get sourceDirectory(): string;
    set sourceDirectory(value: string);
    resetSourceDirectory(): void;
    get sourceDirectoryInput(): string | undefined;
    private _tagPrefix?;
    get tagPrefix(): string;
    set tagPrefix(value: string);
    resetTagPrefix(): void;
    get tagPrefixInput(): string | undefined;
    private _tags?;
    get tags(): boolean | cdktf.IResolvable;
    set tags(value: boolean | cdktf.IResolvable);
    resetTags(): void;
    get tagsInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module tfe_registry_module}
*/
export declare class RegistryModule extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_registry_module";
    /**
    * Generates CDKTF code for importing a RegistryModule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RegistryModule to import
    * @param importFromId The id of the existing RegistryModule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RegistryModule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/registry_module tfe_registry_module} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RegistryModuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: RegistryModuleConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialVersion?;
    get initialVersion(): string;
    set initialVersion(value: string);
    resetInitialVersion(): void;
    get initialVersionInput(): string | undefined;
    private _moduleProvider?;
    get moduleProvider(): string;
    set moduleProvider(value: string);
    resetModuleProvider(): void;
    get moduleProviderInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _noCode?;
    get noCode(): boolean | cdktf.IResolvable;
    set noCode(value: boolean | cdktf.IResolvable);
    resetNoCode(): void;
    get noCodeInput(): boolean | cdktf.IResolvable | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    get publishingMechanism(): string;
    private _registryName?;
    get registryName(): string;
    set registryName(value: string);
    resetRegistryName(): void;
    get registryNameInput(): string | undefined;
    private _testConfig;
    get testConfig(): RegistryModuleTestConfigList;
    putTestConfig(value: RegistryModuleTestConfig[] | cdktf.IResolvable): void;
    resetTestConfig(): void;
    get testConfigInput(): cdktf.IResolvable | RegistryModuleTestConfig[] | undefined;
    private _vcsRepo;
    get vcsRepo(): RegistryModuleVcsRepoOutputReference;
    putVcsRepo(value: RegistryModuleVcsRepo): void;
    resetVcsRepo(): void;
    get vcsRepoInput(): RegistryModuleVcsRepo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
