/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeRegistryProvidersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the organization. If omitted, organization must be defined in the provider config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_providers#organization DataTfeRegistryProviders#organization}
    */
    readonly organization?: string;
    /**
    * Whether to list only public or private providers. Must be either `public` or `private`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_providers#registry_name DataTfeRegistryProviders#registry_name}
    */
    readonly registryName?: string;
    /**
    * A query string to do a fuzzy search on provider name and namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_providers#search DataTfeRegistryProviders#search}
    */
    readonly search?: string;
}
export interface DataTfeRegistryProvidersProviders {
}
export declare function dataTfeRegistryProvidersProvidersToTerraform(struct?: DataTfeRegistryProvidersProviders): any;
export declare function dataTfeRegistryProvidersProvidersToHclTerraform(struct?: DataTfeRegistryProvidersProviders): any;
export declare class DataTfeRegistryProvidersProvidersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeRegistryProvidersProviders | undefined;
    set internalValue(value: DataTfeRegistryProvidersProviders | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    get namespace(): string;
    get organization(): string;
    get registryName(): string;
    get updatedAt(): string;
}
export declare class DataTfeRegistryProvidersProvidersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeRegistryProvidersProvidersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_providers tfe_registry_providers}
*/
export declare class DataTfeRegistryProviders extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_registry_providers";
    /**
    * Generates CDKTF code for importing a DataTfeRegistryProviders resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeRegistryProviders to import
    * @param importFromId The id of the existing DataTfeRegistryProviders that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_providers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeRegistryProviders to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_providers tfe_registry_providers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeRegistryProvidersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeRegistryProvidersConfig);
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _providers;
    get providers(): DataTfeRegistryProvidersProvidersList;
    private _registryName?;
    get registryName(): string;
    set registryName(value: string);
    resetRegistryName(): void;
    get registryNameInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
