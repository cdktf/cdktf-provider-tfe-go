/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TestVariableConfig extends cdktf.TerraformMetaArguments {
    /**
    * Whether this is a Terraform or environment variable. Valid values are "terraform" or "env".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#category TestVariable#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#description TestVariable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#hcl TestVariable#hcl}
    */
    readonly hcl?: boolean | cdktf.IResolvable;
    /**
    * Name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#key TestVariable#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#module_name TestVariable#module_name}
    */
    readonly moduleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#module_provider TestVariable#module_provider}
    */
    readonly moduleProvider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#organization TestVariable#organization}
    */
    readonly organization: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#sensitive TestVariable#sensitive}
    */
    readonly sensitive?: boolean | cdktf.IResolvable;
    /**
    * Value of the variable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#value TestVariable#value}
    */
    readonly value?: string;
    /**
    * Value of the variable in write-only mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#value_wo TestVariable#value_wo}
    */
    readonly valueWo?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable tfe_test_variable}
*/
export declare class TestVariable extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_test_variable";
    /**
    * Generates CDKTF code for importing a TestVariable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TestVariable to import
    * @param importFromId The id of the existing TestVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TestVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/resources/test_variable tfe_test_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TestVariableConfig
    */
    constructor(scope: Construct, id: string, config: TestVariableConfig);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hcl?;
    get hcl(): boolean | cdktf.IResolvable;
    set hcl(value: boolean | cdktf.IResolvable);
    resetHcl(): void;
    get hclInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _moduleName?;
    get moduleName(): string;
    set moduleName(value: string);
    get moduleNameInput(): string | undefined;
    private _moduleProvider?;
    get moduleProvider(): string;
    set moduleProvider(value: string);
    get moduleProviderInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get readableValue(): string;
    private _sensitive?;
    get sensitive(): boolean | cdktf.IResolvable;
    set sensitive(value: boolean | cdktf.IResolvable);
    resetSensitive(): void;
    get sensitiveInput(): boolean | cdktf.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueWo?;
    get valueWo(): string;
    set valueWo(value: string);
    resetValueWo(): void;
    get valueWoInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
