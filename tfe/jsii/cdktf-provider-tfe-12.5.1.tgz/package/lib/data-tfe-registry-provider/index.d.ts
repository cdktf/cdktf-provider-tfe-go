/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeRegistryProviderConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_provider#name DataTfeRegistryProvider#name}
    */
    readonly name: string;
    /**
    * The namespace of the provider. For private providers this is the same as the oraganization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_provider#namespace DataTfeRegistryProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the organization. If omitted, organization must be defined in the provider config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_provider#organization DataTfeRegistryProvider#organization}
    */
    readonly organization?: string;
    /**
    * Whether this is a publicly maintained provider or private. Must be either `public` or `private`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_provider#registry_name DataTfeRegistryProvider#registry_name}
    */
    readonly registryName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_provider tfe_registry_provider}
*/
export declare class DataTfeRegistryProvider extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_registry_provider";
    /**
    * Generates CDKTF code for importing a DataTfeRegistryProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeRegistryProvider to import
    * @param importFromId The id of the existing DataTfeRegistryProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeRegistryProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.71.0/docs/data-sources/registry_provider tfe_registry_provider} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeRegistryProviderConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeRegistryProviderConfig);
    get createdAt(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _registryName?;
    get registryName(): string;
    set registryName(value: string);
    resetRegistryName(): void;
    get registryNameInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
